function OpenRemoteControl(){

    var anotherwindow=window.open("RemoteControl.html","RemoteCtrl","width=300,height=300")

}
function AlertOnMain(){
    window.opener.alert("This Window is the opener")
}

function ColorSettings1(color1,color2,color3){
// https://stackoverflow.com/questions/66241300/javascript-change-colour-of-element-on-click-with-if-statement#:~:text=You%20can%20use%20Element.,the%20color%20of%20your%20element.
// check the above link later to set the specific colors brotha good luck
}